#include "CSE7759.h"
#include "Config.h"

CSE7759::CSE7759() {
}

void CSE7759::initialize_power_data(PowerData* data) {
  memset(data, 0, sizeof(PowerData));
  data->test_flag = 0;
  data->checksum = 255;
}

int CSE7759::hex_to_dec(const char* hex) {
  long long decimal = 0;
  int len = strlen(hex) - 1;

  for (int i = 0; hex[i] != '\0'; i++) {
    int val;
    if (hex[i] >= '0' && hex[i] <= '9') {
      val = hex[i] - '0';
    } else if (hex[i] >= 'a' && hex[i] <= 'f') {
      val = hex[i] - 'a' + 10;
    } else if (hex[i] >= 'A' && hex[i] <= 'F') {
      val = hex[i] - 'A' + 10;
    } else {
      return -1;  // Invalid hex character
    }
    decimal += val * pow(16, len);
    len--;
  }
  return decimal;
}

void CSE7759::prepare_hex(unsigned int byte1, unsigned int byte2, unsigned int byte3, char* hex) {
  if (byte1 < 16 && byte2 < 16 && byte3 < 16) {
    sprintf(hex, "0%x0%x0%x", byte1, byte2, byte3);
  } else if (byte1 < 16) {
    sprintf(hex, "0%x%x%x", byte1, byte2, byte3);
  } else if (byte2 < 16) {
    sprintf(hex, "%x0%x%x", byte1, byte2, byte3);
  } else if (byte3 < 16) {
    sprintf(hex, "%x%x0%x", byte1, byte2, byte3);
  } else {
    sprintf(hex, "%x%x%x", byte1, byte2, byte3);
  }
}

void CSE7759::calculate_power(PowerData* data) {
  char temp_hex[10];
  float temp1, temp2, temp3;

  prepare_hex(data->readings[2], data->readings[3], data->readings[4], temp_hex);
  temp1 = hex_to_dec(temp_hex);
  prepare_hex(data->readings[5], data->readings[6], data->readings[7], temp_hex);
  temp2 = hex_to_dec(temp_hex);

  data->voltage = data->test_flag ? 0 : temp1 / temp2;

  prepare_hex(data->readings[8], data->readings[9], data->readings[10], temp_hex);
  temp1 = hex_to_dec(temp_hex);
  prepare_hex(data->readings[11], data->readings[12], data->readings[13], temp_hex);
  temp2 = hex_to_dec(temp_hex);

  data->current = data->test_flag ? 0 : temp1 / temp2;

  prepare_hex(data->readings[14], data->readings[15], data->readings[16], temp_hex);
  temp1 = hex_to_dec(temp_hex);
  prepare_hex(data->readings[17], data->readings[18], data->readings[19], temp_hex);
  temp2 = hex_to_dec(temp_hex);

  data->power = data->test_flag ? 0 : temp1 / temp2;
  data->test_flag = 0;
}

PowerData CSE7759::read_power_data() {
  PowerData data;
  initialize_power_data(&data);
  unsigned char byte;
  unsigned int Checksum = 0;

  //Serial.println("Reading Chip...");

  for (int i = 0; i <= 100; i++) {
    byte = Serial.read();
    if (byte == 85) {
      data.readings[0] = byte;
      byte = Serial.read();
      if (byte == 90) {
        data.readings[1] = byte;
        for (int j = 2; j <= 23; j++) {
          data.readings[j] = Serial.read();
        }
        // for (int x = 2; x <= 22; x++) {
        //   Checksum += data.readings[x];
        // }
        // if ((Checksum & data.checksum) == data.readings[23]) {
        calculate_power(&data);
        return data;  // Return the data object with the calculated values
        // }
      }
    }
  }
  return data;  // Return the data object even if no valid data was read
}

// AMit

// Add a new sample into the buffer
void CSE7759::addSamplesForPower(float value) {
  samplesForPowerCSE1[indexForPowerCSE1] = value;
  indexForPowerCSE1 = (indexForPowerCSE1 + 1) % 10;  // wrap around (circular buffer)
  if (indexForPowerCSE1 == 0) bufferFilledForPowerCSE1 = true;
}

// Calculate moving average
float CSE7759::getAverageForPower() {
  float sum = 0;
  int count = bufferFilledForPowerCSE1 ? 10 : indexForPowerCSE1;  // use only filled values
  for (int i = 0; i < count; i++) {
    sum += samplesForPowerCSE1[i];
  }
  return (count > 0) ? (sum / count) : 0;
}

// Add a new sample into the buffer
void CSE7759::addSamplesForCurrent(float value) {
  samplesForCurrentCSE1[indexForCurrentCSE1] = value;
  indexForCurrentCSE1 = (indexForCurrentCSE1 + 1) % 10;  // wrap around (circular buffer)
  if (indexForCurrentCSE1 == 0) bufferFilledForCurrentCSE1 = true;
}

// Calculate moving average
float CSE7759::getAverageForCurrent() {
  float sum = 0;
  int count = bufferFilledForCurrentCSE1 ? 10 : indexForCurrentCSE1;  // use only filled values
  for (int i = 0; i < count; i++) {
    sum += samplesForCurrentCSE1[i];
  }
  return (count > 0) ? (sum / count) : 0;
}

// Add a new sample into the buffer
void CSE7759::addSamplesForVoltage(float value) {
  samplesForVoltageCSE1[indexForVoltageCSE1] = value;
  indexForVoltageCSE1 = (indexForVoltageCSE1 + 1) % 10;  // wrap around (circular buffer)
  if (indexForVoltageCSE1 == 0) bufferFilledForVoltageCSE1 = true;
}

// Calculate moving average
float CSE7759::getAverageForVoltage() {
  float sum = 0;
  int count = bufferFilledForVoltageCSE1 ? 10 : indexForVoltageCSE1;  // use only filled values
  for (int i = 0; i < count; i++) {
    sum += samplesForVoltageCSE1[i];
  }
  return (count > 0) ? (sum / count) : 0;
}

/*
  INPUT: VOLTAGE, CURRENT, POWER STRUCTURE AND RELAY STATUS FLAG
  OUTPUT: VERIFIED VOLTAGE, CURRENT, POWER STRUCTURE
  OPERATION: CHECKING IF RECEIEVED DATA IS GARBAGE. IF YES, THEN RE-REQUEST FOR DATA. TRYING IT FOR 5 TIMES, IF STILL GETTING GARBAGE DATA THEN RETURNING THE PREVIOUS CORRECT DATA.
*/
PowerData CSE7759::validateTheCSEChipData(PowerData powerData) {
  // Serial.println("*****************************CSE1***********************");  // Print debug header

  float current_power = powerData.power;      // Local copy of current power
  float current_current = powerData.current;  // Local copy of current current
  float current_voltage = powerData.voltage;  // Local copy of current voltage

  // Replace invalid (infinite) readings with last good value
  if (isinf(powerData.power) || isinf(powerData.current) || isinf(powerData.voltage)) {
    if (isinf(powerData.power)) {
      powerData.power = powerPre;  // Use last valid power
    }
    if (isinf(powerData.current)) {
      powerData.current = currentPre;  // Use last valid current
    }
    if (isinf(powerData.voltage)) {
      powerData.voltage = voltagePre;  // Use last valid voltage
    }
  }

  addSamplesForPower(powerData.power);
  float avgForPower = getAverageForPower();
  // Validate power data (reject if >5x or <1/5 of last 3 readings)
  if ((powerData.power > (avgForPower + 100)) || (powerData.power < (avgForPower - 100))) {
    current_power = powerData.power;  // Save rejected value
    // Serial.print("current_power : ");
    // Serial.println(current_power);
    powerData.power = powerPre;  // Replace with last valid
    // Serial.print("powerData.power : ");
    // Serial.println(powerData.power);
  } else {
    powerPre = powerData.power;  // Update last valid power
    // Serial.print("powerPre : ");
    // Serial.println(powerPre);
  }

  addSamplesForCurrent(powerData.current);
  float avgForCurrent = getAverageForCurrent();
  // Validate current data
  if ((powerData.current > (avgForCurrent + 100)) || (powerData.current < (avgForCurrent - 100))) {
    current_current = powerData.current;  // Save rejected value
    // Serial.print("current_current : ");
    // Serial.println(current_current);
    powerData.current = currentPre;  // Replace with last valid
    // Serial.print("powerData.current : ");
    // Serial.println(powerData.current);
  } else {
    currentPre = powerData.current;  // Update last valid current
    // Serial.print("currentPre : ");
    // Serial.println(currentPre);
  }

  addSamplesForVoltage(powerData.voltage);
  float avgForVoltage = getAverageForVoltage();
  // Validate voltage data
  if ((powerData.voltage > (avgForVoltage + 100)) || (powerData.voltage < (avgForVoltage - 100))) {
    current_voltage = powerData.voltage;  // Save rejected value
    // Serial.print("current_voltage : ");
    // Serial.println(current_voltage);
    powerData.voltage = voltagePre;  // Replace with last valid
    // Serial.print("powerData.voltage : ");
    // Serial.println(powerData.voltage);
  } else {
    voltagePre = powerData.voltage;  // Update last valid voltage
    // Serial.print("voltagePre : ");
    // Serial.println(voltagePre);
  }

  // Serial.print("Moving Power Avg : ");
  // Serial.println(avgForPower);
  // Serial.print("Moving Current Avg : ");
  // Serial.println(avgForCurrent);
  // Serial.print("Moving Voltage Avg : ");
  // Serial.println(avgForCurrent);

  return powerData;
}
